package permission;

public enum PermissionType {
    ADMIN, MANAGER, CUSTOMER
}
