package permission;

public abstract class Action {
    public abstract void  perform(User user, String data);
}
